// ═══════════════════════════════════════════════════════════════════════════════
// Ozzyl HMS — DICOM Print Agent: C-STORE SCP (Service Class Provider)
//
// This module creates a DICOM server that listens for incoming C-STORE requests
// from X-ray machines (CR/DR modalities). When an image is received, it:
//   1. Saves the DICOM file locally
//   2. Emits an 'imageReceived' event so other modules can process it
//
// Based on dcmjs-dimse official documentation (context7 verified).
// ═══════════════════════════════════════════════════════════════════════════════

const dcmjsDimse = require('dcmjs-dimse');
const { Dataset, Server, Scp } = dcmjsDimse;
const { CStoreResponse, CEchoResponse } = dcmjsDimse.responses;
const {
  Status,
  PresentationContextResult,
  TransferSyntax,
  SopClass,
  StorageClass,
} = dcmjsDimse.constants;
const EventEmitter = require('events');
const fs = require('fs');
const path = require('path');
const logger = require('./logger');
const { config } = require('./config');

class DicomScp extends EventEmitter {
  constructor() {
    super();
    this.server = null;
    this.stats = {
      received: 0,
      failed: 0,
      lastReceived: null,
      startedAt: null,
    };
  }

  /**
   * Start the DICOM SCP server
   */
  async start() {
    // Ensure storage directory exists
    if (!fs.existsSync(config.storagePath)) {
      fs.mkdirSync(config.storagePath, { recursive: true });
    }

    // Reference to this DicomScp instance for use inside the Scp class
    const scpInstance = this;

    // Create the SCP handler class
    class OzzylStoreScp extends Scp {
      constructor(socket, opts) {
        super(socket, opts);
        this.association = undefined;
      }

      /**
       * Handle incoming association requests from X-ray machines.
       * We accept all standard Storage SOP Classes and Verification.
       */
      associationRequested(association) {
        this.association = association;

        const callingAe = association.getCallingAeTitle();
        const calledAe = association.getCalledAeTitle();
        logger.info(`Association requested: ${callingAe} → ${calledAe}`);

        // Accept all storage presentation contexts
        const contexts = association.getPresentationContexts();
        contexts.forEach((c) => {
          const context = association.getPresentationContext(c.id);
          const abstractSyntax = context.getAbstractSyntaxUid();

          // Accept Verification (C-ECHO) and all Storage classes
          if (
            abstractSyntax === SopClass.Verification ||
            Object.values(StorageClass).includes(abstractSyntax)
          ) {
            const transferSyntaxes = context.getTransferSyntaxUids();
            transferSyntaxes.forEach((ts) => {
              if (
                ts === TransferSyntax.ImplicitVRLittleEndian ||
                ts === TransferSyntax.ExplicitVRLittleEndian
              ) {
                context.setResult(PresentationContextResult.Accept, ts);
              } else {
                context.setResult(PresentationContextResult.RejectTransferSyntaxesNotSupported);
              }
            });
          } else {
            context.setResult(PresentationContextResult.RejectAbstractSyntaxNotSupported);
          }
        });

        this.sendAssociationAccept();
      }

      /**
       * Handle C-ECHO (DICOM ping) — used by machines to verify connectivity
       */
      cEchoRequest(request, callback) {
        logger.info('C-ECHO received (connectivity test)');
        const response = CEchoResponse.fromRequest(request);
        response.setStatus(Status.Success);
        callback(response);
      }

      /**
       * Handle incoming C-STORE requests — this is where X-ray images arrive
       */
      cStoreRequest(request, callback) {
        const dataset = request.getDataset();
        const response = CStoreResponse.fromRequest(request);

        try {
          // Extract DICOM metadata
          const sopInstanceUid = dataset.getElement('SOPInstanceUID') || 'unknown';
          const studyInstanceUid = dataset.getElement('StudyInstanceUID') || 'unknown';
          const patientName = dataset.getElement('PatientName') || 'Unknown';
          const patientId = dataset.getElement('PatientID') || '';
          const modality = dataset.getElement('Modality') || 'OT';
          const studyDate = dataset.getElement('StudyDate') || '';
          const studyDescription = dataset.getElement('StudyDescription') || '';
          const sopClassUid = dataset.getElement('SOPClassUID') || '';

          logger.info(`C-STORE received: ${patientName} [${modality}] SOP: ${sopInstanceUid.substring(0, 30)}...`);

          // Create study subfolder: received/<studyInstanceUid>/
          const studyDir = path.join(config.storagePath, studyInstanceUid.replace(/[^a-zA-Z0-9.-]/g, '_'));
          if (!fs.existsSync(studyDir)) {
            fs.mkdirSync(studyDir, { recursive: true });
          }

          // Save DICOM file
          const filePath = path.join(studyDir, `${sopInstanceUid}.dcm`);
          dataset.toFile(filePath, (err) => {
            if (err) {
              logger.error(`Failed to save DICOM file: ${err.message}`);
              response.setStatus(Status.ProcessingFailure);
              scpInstance.stats.failed++;
              callback(response);
              return;
            }

            logger.info(`Saved: ${filePath}`);
            scpInstance.stats.received++;
            scpInstance.stats.lastReceived = new Date().toISOString();

            // Emit event for printing and cloud sync
            scpInstance.emit('imageReceived', {
              filePath,
              studyDir,
              metadata: {
                sopInstanceUid,
                studyInstanceUid,
                sopClassUid,
                patientName,
                patientId,
                modality,
                studyDate,
                studyDescription,
              },
            });

            response.setStatus(Status.Success);
            callback(response);
          });
        } catch (err) {
          logger.error(`C-STORE processing error: ${err.message}`);
          response.setStatus(Status.ProcessingFailure);
          scpInstance.stats.failed++;
          callback(response);
        }
      }

      /**
       * Handle association release
       */
      associationReleaseRequested() {
        logger.info('Association released');
        this.sendAssociationReleaseResponse();
      }
    }

    // Initialize the server
    this.server = new Server(OzzylStoreScp);

    this.server.on('networkError', (e) => {
      logger.error(`DICOM network error: ${e.message}`);
    });

    // Start listening
    this.server.listen(config.dicomPort);
    this.stats.startedAt = new Date().toISOString();

    logger.info('═══════════════════════════════════════════════════');
    logger.info(`  DICOM C-STORE SCP started`);
    logger.info(`  AE Title : ${config.aeTitle}`);
    logger.info(`  Port     : ${config.dicomPort}`);
    logger.info(`  Storage  : ${config.storagePath}`);
    logger.info('═══════════════════════════════════════════════════');
  }

  /**
   * Stop the server gracefully
   */
  stop() {
    if (this.server) {
      this.server.close();
      logger.info('DICOM SCP server stopped');
    }
  }

  /**
   * Get server statistics
   */
  getStats() {
    return { ...this.stats };
  }
}

module.exports = DicomScp;
