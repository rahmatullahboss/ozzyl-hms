# Ozzyl HMS — DICOM Print Agent 🖨️

**Local hospital middleware** that receives X-ray images from CR/DR modalities via DICOM protocol, automatically prints them to any local printer, and syncs to the Ozzyl HMS cloud.

> Think of this as a bridge between the hospital's X-ray machine (which speaks DICOM) and your printer + cloud HMS (which speak HTTP).

## How It Works

```
┌─────────────────┐         ┌─────────────────────┐         ┌──────────────┐
│  X-Ray Machine  │  DICOM  │  Hospital PC         │  USB   │  Any Printer │
│  (CR/DR)        │ C-STORE │  (DICOM Print Agent) │────────│  (Epson, HP, │
│                 │────────▶│                       │        │   Canon...)  │
│  AE: XRAY_01   │ :4006   │  AE: OZZYL_PRINT     │        └──────────────┘
│  IP: 192.168.1.5│         │  IP: 192.168.1.100   │
└─────────────────┘         │                       │  HTTPS
                            │                       │────────▶ Ozzyl HMS Cloud
                            └─────────────────────┘          (Cloudflare R2)
```

### Pipeline

1. **X-ray machine** sends a DICOM C-STORE request to this agent
2. Agent **saves** the `.dcm` file locally
3. Agent **converts** DICOM → PNG with proper Window/Level contrast
4. Agent **prints** the image to the configured printer
5. Agent **syncs** the DICOM file to Ozzyl HMS cloud (background, non-blocking)

### Key Features

- 🖨️ **Any Printer** — Works with Epson, HP, Canon, Brother, or ANY printer installed on the OS
- 📡 **DICOM Standard** — Full C-STORE SCP + C-ECHO support
- ☁️ **Cloud Sync** — Auto-uploads to Ozzyl HMS with offline queue & retry
- 🖼️ **Smart Conversion** — Window/Level, MONOCHROME1/2, 8/16-bit grayscale
- 📄 **Multiple Film Sizes** — 8×10, 10×12, 11×14, 14×17, A4, Letter
- 🪟 **Cross-Platform** — Windows, Linux, macOS
- 🔄 **Auto-Start** — Install as Windows Service / Linux systemd / macOS launchd

---

## Prerequisites

| Item | Details |
|------|---------|
| **Node.js** | v18+ ([download](https://nodejs.org)) |
| **Computer** | Windows 10/11, Linux, or macOS |
| **Printer** | Any printer connected to this computer |
| **Network** | Computer & X-ray machine must be on the same LAN |
| **Internet** | Optional — needed only for cloud sync |

---

## Quick Start

### 1. Install

```bash
cd tools/dicom-print-agent
npm install
```

### 2. Configure

```bash
cp .env.example .env
# Edit .env with your settings
```

**Minimum required settings:**

```ini
DICOM_PORT=4006
AE_TITLE=OZZYL_PRINT
PRINTER_NAME=EPSON L1300 Series    # Your printer name (or leave blank for default)
OZZYL_API_KEY=your_key             # From HMS admin panel
TENANT_ID=your_tenant_id           # Your hospital tenant ID
```

### 3. Run

```bash
npm start
```

You should see:

```
  ╔═══════════════════════════════════════════════════════════╗
  ║          Ozzyl HMS — DICOM Print Agent v1.0.0           ║
  ╠═══════════════════════════════════════════════════════════╣
  ║  AE Title    : OZZYL_PRINT                              ║
  ║  DICOM Port  : 4006                                     ║
  ║  Printing    : ENABLED                                  ║
  ║  Cloud Sync  : ENABLED                                  ║
  ║  Paper Size  : 14×17 inch                               ║
  ╚═══════════════════════════════════════════════════════════╝
```

### 4. Configure X-Ray Machine

In your X-ray machine's **DICOM Print** or **DICOM Store** settings:

| Setting | Value |
|---------|-------|
| **AE Title** | `OZZYL_PRINT` |
| **IP Address** | This computer's IP (e.g., `192.168.1.100`) |
| **Port** | `4006` |

### 5. Test

Send a test X-ray from the machine. You should see:

```
[10:30:15] info: Association requested: XRAY_01 → OZZYL_PRINT
[10:30:15] info: C-STORE received: DOE^JOHN [CR] SOP: 1.2.840.113619...
[10:30:15] info: Saved: received/1.2.840.../1.2.840...dcm
[10:30:16] info: PNG created: 1.2.840...png (2048×2048 → fit 14×17 inch)
[10:30:17] info: Print job sent successfully
[10:30:18] info: Cloud sync complete
```

---

## Install as Auto-Start Service

### Windows

```batch
REM Run as Administrator
scripts\install-windows.bat
```

This installs a Windows Service called `OzzylDicomPrint` that starts automatically with Windows.

### Linux

```bash
sudo bash scripts/install-linux.sh
```

### macOS

```bash
bash scripts/install-linux.sh
```

---

## Configuration Reference

| Variable | Default | Description |
|----------|---------|-------------|
| `DICOM_PORT` | `4006` | TCP port for DICOM SCP server |
| `AE_TITLE` | `OZZYL_PRINT` | DICOM Application Entity title |
| `PRINT_ENABLED` | `true` | Enable/disable auto-printing |
| `PRINTER_NAME` | *(empty)* | OS printer name (empty = default printer) |
| `PAPER_SIZE` | `14x17` | Film size: `8x10`, `10x12`, `11x14`, `14x17`, `A4`, `Letter` |
| `CLOUD_SYNC_ENABLED` | `true` | Enable/disable cloud upload |
| `OZZYL_API_URL` | — | Ozzyl HMS PACS API URL |
| `OZZYL_API_KEY` | — | API key for agent authentication |
| `TENANT_ID` | — | Hospital tenant ID |
| `STORAGE_PATH` | `./received` | Local DICOM file storage |
| `LOG_PATH` | `./logs` | Log files directory |
| `LOG_LEVEL` | `info` | `error`, `warn`, `info`, `debug` |

---

## Supported Printers

This agent works with **any printer** that is installed and accessible from the operating system. The printing module uses the OS print spooler (SumatraPDF on Windows, lpr on Linux/macOS), so there is no printer brand lock-in.

**Tested with:**
- Epson L1300 / L1800 (inkjet, large format)
- HP LaserJet Pro series
- Canon imagePROGRAF series
- Brother HL series
- Any network printer accessible via Windows/Linux print spooler

---

## Troubleshooting

### "No printers detected"
- Make sure the printer is installed in Windows (Devices and Printers)
- Try printing a test page from Windows first

### "DICOM connection refused"
- Check if firewall is blocking port 4006
- Run `netstat -an | findstr 4006` to verify the port is listening
- Ping this computer from the X-ray machine to verify network

### "Cloud sync failed"
- Check your API key and tenant ID in `.env`
- The agent will automatically retry every 60 seconds
- Check `logs/error.log` for details

### X-ray machine can't find this agent
- Verify the AE Title matches exactly (case-sensitive)
- Verify the IP address is correct
- Some machines require adding this agent in their "DICOM Peers" or "Destinations" list

---

## হাসপাতালে ইনস্টলেশন গাইড (বাংলা)

### প্রয়োজনীয় জিনিস
- একটি কম্পিউটার (Windows 10/11)
- Node.js ইনস্টল করা (https://nodejs.org)
- প্রিন্টার কম্পিউটারের সাথে কানেক্ট থাকতে হবে
- কম্পিউটার ও এক্স-রে মেশিন একই নেটওয়ার্কে থাকতে হবে

### ধাপ ১: Node.js ইনস্টল
- https://nodejs.org থেকে LTS ভার্সন ডাউনলোড করুন
- ইনস্টল করুন (সব ডিফল্ট সেটিংস রাখুন)

### ধাপ ২: DICOM Print Agent ইনস্টল
```
cd C:\OzzylHMS\dicom-print-agent
npm install
```

### ধাপ ৩: কনফিগারেশন
- `.env.example` ফাইলটি কপি করে `.env` নাম দিন
- `.env` ফাইলে আপনার প্রিন্টারের নাম লিখুন
- Ozzyl HMS থেকে API Key নিন

### ধাপ ৪: এক্স-রে মেশিন সেটআপ
- মেশিনের DICOM/Print সেটিংসে যান
- AE Title: `OZZYL_PRINT`
- IP: এই কম্পিউটারের IP
- Port: `4006`

### ধাপ ৫: চালু করুন
```
npm start
```

### ধাপ ৬: অটো-স্টার্ট সেটআপ (ঐচ্ছিক)
- `scripts\install-windows.bat` ফাইলটি Administrator হিসেবে চালান
- এরপর কম্পিউটার রিস্টার্ট হলেও সফটওয়্যার নিজে চালু হবে

---

## Architecture

This agent follows the same pattern as the [HL7 Agent](../hl7-agent/README.md):

| Component | HL7 Agent | DICOM Print Agent |
|-----------|-----------|-------------------|
| **Protocol** | TCP/MLLP (HL7v2) | TCP/DICOM (C-STORE) |
| **Source** | Lab analyzers | X-ray machines |
| **Local Action** | — | Print to local printer |
| **Cloud Sync** | POST to `/lab/machine/receive` | POST to `/radiology/pacs` |
| **Library** | `hl7-standard` | `dcmjs-dimse` |

---

## License

Part of Ozzyl HMS. Private and proprietary.
